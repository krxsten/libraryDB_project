﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Library_Project
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();

            while (true)
            {
                Console.WriteLine("1. Добавяне на книга");
                Console.WriteLine("2. Добавяне на читател");
                Console.WriteLine("3. Добавяне на заеманите книги");
                Console.WriteLine("4. Заемане на книга");
                Console.WriteLine("5. Връщане на книга");
                Console.WriteLine("6. Показване на всички книги");
                Console.WriteLine("7. Показване на всички читатели");
                Console.WriteLine("8. Показване на всички заети книги");
                Console.WriteLine("0. Изход");
                Console.Write("Вашият избор: ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.Write("Въведете заглавие: ");
                        string title = Console.ReadLine();
                        Console.Write("Въведете автор: ");
                        string author = Console.ReadLine();
                        Console.Write("Въведете жанр: ");
                        string genre = Console.ReadLine();
                        Console.Write("Въведете брой копия: ");
                        int copies = int.Parse(Console.ReadLine());
                        Console.Write("Въведете заети книги: ");
                        int borrowed = int.Parse(Console.ReadLine());
                        library.AddBook(title, author, genre, copies, borrowed);
                        break;

                    case 2:
                        Console.Write("Въведете име: ");
                        string name = Console.ReadLine();
                        Console.WriteLine("Въведете ID: ");
                        int id = int.Parse(Console.ReadLine());
                        Console.Write("Въведете възраст: ");
                        int age = int.Parse(Console.ReadLine());
                        library.AddReader(name, id, age);
                        break;
                    case 3:
                        int readerID=int.Parse(Console.ReadLine());
                        int bookID = int.Parse(Console.ReadLine());
                        DateTime borrowdate = new DateTime(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));
                        DateTime returndate = new DateTime(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));
                        library.AddLoans(readerID, bookID, borrowdate, returndate);
                        break;

                    case 4:
                        Console.Write("Reader ID: ");
                        int readerId = int.Parse(Console.ReadLine());
                        Console.Write("Book ID: ");
                        int bookId = int.Parse(Console.ReadLine());
                        library.BorrowBook(readerId, bookId);
                        break;

                    case 5:
                        Console.Write("Loan ID: ");
                        int loanId = int.Parse(Console.ReadLine());
                        library.ReturnBook(loanId);
                        break;

                    case 6:
                        library.PrintEverythingFromBooks();
                        break;
                    case 7:
                        library.PrintEverythingFromReaders();
                        break;
                    case 8:
                        library.PrintEverythingFromLoans();
                        break;
                    case 0:
                        return;
                }
                Console.WriteLine("1. Добавяне на книга");
                Console.WriteLine("2. Добавяне на читател");
                Console.WriteLine("3. Добавяне на заеманите книги");
                Console.WriteLine("4. Заемане на книга");
                Console.WriteLine("5. Връщане на книга");
                Console.WriteLine("6. Показване на всички книги");
                Console.WriteLine("7. Показване на всички читатели");
                Console.WriteLine("8. Показване на всички заети книги");
                Console.WriteLine("0. Изход");
                Console.Write("Вашият избор: ");
                choice = int.Parse(Console.ReadLine());
            }
        }
    }
}
