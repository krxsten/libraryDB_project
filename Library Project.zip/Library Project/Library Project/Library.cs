﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Project
{
    public class Library
    {
        public string connectionString = "Data Source=STUDENT14;Initial Catalog=LibraryDB;Integrated Security=True;Trust Server Certificate=True";

        public void AddBook(string title, string author, string genre, int copies, int borrowed)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [Books]([title],[author],[genre],[available_copies],[times_borrowed]) Values (@title,@author,@genre,@available_copies,@times_borrowed)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@author", author);
                cmd.Parameters.AddWithValue("@genre", genre);
                cmd.Parameters.AddWithValue("@available_copies", copies);
                cmd.Parameters.AddWithValue("@times_borrowed", borrowed);
                cmd.ExecuteNonQuery();
            }
        }

        public void AddReader(string name, int id,int age)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO [Readers](name, identification_num, age) values (@name, @identification_num, age)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@identification_num", id);
                cmd.Parameters.AddWithValue("@age", age);
                cmd.ExecuteNonQuery();
            }
        }
        public void AddLoans(int readerID, int bookID, DateTime borrowdate, DateTime returndate)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Loans ([reader_id], [book_id], [borrow_date], [return_date]) values (@reader_id, @book_id, @borrow_date, @return_date)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@reader_id", readerID);
                cmd.Parameters.AddWithValue("@book_id", bookID);
                cmd.Parameters.AddWithValue("@borrow_date", borrowdate);
                cmd.Parameters.AddWithValue("@return_date", returndate);
                cmd.ExecuteNonQuery();
            }
        }

        public void BorrowBook(int readerId, int bookId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string checkQuery = "SELECT [@available_copies] FROM Books WHERE id = @BookId";
                SqlCommand command = new SqlCommand(checkQuery, conn);
                command.Parameters.AddWithValue("@BookId", bookId);
                int availableCopies = (int)command.ExecuteScalar();
            }
        }

        public void ReturnBook(int loanId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string getBookIdQuery = "SELECT [book_id] FROM Loans WHERE id = @LoanId AND [return_date] IS NULL";
                SqlCommand getBookCmd = new SqlCommand(getBookIdQuery, conn);
                getBookCmd.Parameters.AddWithValue("@LoanId", loanId);
                object result = getBookCmd.ExecuteScalar();
            }
        }

        public void PrintEverythingFromBooks()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Books";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader[0]} \nTitle{reader[1]} \nAuthor{reader[2]}  \nAvailable Copies:{reader[3]} \nTimes borrowed: {reader[4]}");
                }
            }
        }
        public void PrintEverythingFromReaders()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Readers";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader[0]} \nNum{reader[1]}  \nIdentification Number:{reader[2]}  \nAge: {reader[3]}");
                }
            }
        }
        public void PrintEverythingFromLoans()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Loans";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader[0]} \nReaderID: {reader[1]}  \nIBookID:{reader[2]}  \nBorrow date: {reader[3]} \nReturn date: {reader[4]}");
                }
            }
        }
    }
}
